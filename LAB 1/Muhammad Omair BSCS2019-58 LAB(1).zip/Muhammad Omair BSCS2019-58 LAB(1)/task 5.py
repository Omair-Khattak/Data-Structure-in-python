intiger = []

size = int(input("Enter number of elements : "))

for i in range(0, size):
     inp = int(input())

     intiger.append(inp)

for i in intiger:

     print(i, end="")
