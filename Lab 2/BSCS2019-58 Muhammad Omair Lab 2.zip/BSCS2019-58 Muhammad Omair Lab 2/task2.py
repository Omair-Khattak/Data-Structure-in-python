def Movemin(list1):
    
    for i in range(0, len(list1)-1):
        min_value = i

        for j in range(i+1, len(list1)):
            if list1[j] < list1[min_value]: #looking for smallest value in list
                min_value = j
        if min_value != i:
            list1[min_value], list1[i] = list1[i], list1[min_value] #swapping 
    return list1


def selection_sort():
    list1 = []
    n = int(input("Enter number of elements : ")) #taking inputs
    for i in range(0, n):
            ele = int(input())
            list1.append(ele)
    print(Movemin(list1))           #use of Movemin fucntion 
selection_sort()