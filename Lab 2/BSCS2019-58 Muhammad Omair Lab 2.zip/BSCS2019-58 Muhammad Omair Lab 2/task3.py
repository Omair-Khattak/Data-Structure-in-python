def GCD(a, b):
    if a>b:
        smaller_number = b
    else:
        smaller_number = a
    for i in range(1, smaller_number+1):
            if ((a%i == 0) and (b%i == 0)):
                gcd = i
    return gcd

n = int(input("Enter Your Element:"))
def rel_prime(n):
    totalcount = 0
    rel_count = 0
    for i in range(1,n):
        for j in range(1,n):
            totalcount = totalcount+1
            if GCD(i,j) == 1:
                rel_count = rel_count+1
    return rel_count/totalcount
print("The probabilty is: ",rel_prime(n))
                