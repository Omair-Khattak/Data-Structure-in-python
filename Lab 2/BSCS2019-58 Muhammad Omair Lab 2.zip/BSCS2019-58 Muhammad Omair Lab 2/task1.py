def insert(list1):
    
    for i in range(1, len(list1)):
        sortValue = list1[i]
        while list1[i-1] > sortValue and i>0:  
            list1[i], list1[i-1] = list1[i-1], list1[i]
            i = i -1
    return list1


def insertion_sort():
    list1 = []
    n = int(input("Enter number of elements : ")) 
    for i in range(0, n):
            ele = int(input())
            list1.append(ele)
    print(insert(list1))           
insertion_sort()
